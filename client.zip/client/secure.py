from Cryptodome.Random import get_random_bytes
from Cryptodome.Cipher import PKCS1_OAEP, AES
from Cryptodome.Util.Padding import pad, unpad
from Cryptodome.PublicKey import RSA
from datetime import datetime
now = datetime.now()
time = now.strftime("%m-%d-%Y_%H+%M+%S")

class secure:        
    # def createTunnel():
    #     self.generate()
    def __init__(self):
        print('')

    def encrypting(self,encType, key,data):
        encType = encType.upper()
        data = data.encode()
        print('plaintext:',data)
        print('-------------')
        if encType == "RSA": #Asymmetric
            pub_key=RSA.import_key(key)
            cipher = PKCS1_OAEP.new(pub_key)
            #print('cipher',cipher)
            encrypted = cipher.encrypt(data)
            #print('encrypted',encrypted)
            #encrypted = encrypted.decode()
            #sprint(encrypted)
            return encrypted
        elif encType == "AES": #symmetric
            BLOCK_SIZE = 16
            
            print('done importing')
            cipher = AES.new(key, AES.MODE_ECB)  # new AES cipher using key generated
            cipher_text_bytes = cipher.encrypt(pad(data,BLOCK_SIZE)) # encrypt data
            print('encrypted data',cipher_text_bytes)
            return cipher_text_bytes
        else:
            print('Not supported')
    def decrypting(self,encType,key,data):
        encType = encType.upper()
        if encType == "RSA":
            print("placeholder for RSA")
            pri_key=RSA.import_key(key)
            keysize=pri_key.size_in_bytes()
            cipher = PKCS1_OAEP.new(pri_key)
            print('encrypting',data)
            plain_text = cipher.decrypt(data)
            return plain_text
        elif encType == "AES": #Symmetric
            print('data',data)
            BLOCK_SIZE = 16  #  AES data block size 128 bits (16 bytes)
            decipher = AES.new(key, AES.MODE_ECB)
            print(data)
            print(decipher.decrypt(data))
        else:
            print('Not supported')

    def generating(self,cipherType,clientOrServer):
        clientOrServer = clientOrServer.upper()
        if clientOrServer =="CLIENT" or "SERVER":
            #Generation of RSA key
            if cipherType == "RSA":
                publicKeyName = f'keys/{clientOrServer}_public.pem'
                privateKeyName = f'keys/{clientOrServer}_private.pem'
                try:
                    with open(privateKeyName,"rb") as f:
                        privateKey = f.read()
                    with open(publicKeyName,"rb") as f:
                        publicKey = f.read()
                    priny(publicKey)
                    priny(privateKey)
                except:
                    print("placeholder for RSA")
                    print("placeholder for generate")
                    print("Generating an RSA key pair...")
                    # Generate a 1024-bit or 2024-bit long RSA Key pair.
                    keypair=RSA.generate(2048)
                    # store the private key to private.pem
                    # store the public key to public.pem
                    with open(privateKeyName,"w") as f:
                        #print(keypair.exportKey().decode() ,file=f)
                        f.write
                        privateKey = keypair.exportKey().decode()
                    f.close()
                    print("Private Key stored on to" ,privateKeyName)
                    
                    with open(publicKeyName,"w") as f:
                        print(keypair.publickey().exportKey().decode() ,file=f)
                        publicKey = keypair.publickey().export_key()
                        print('publicKey',publicKey)
                    f.close()
                    #print("Public Key stored on to", publicKeyName)
                return publicKey,privateKey
            #Generation of AES
            elif cipherType == "AES": #Symmetric
                aeskey=get_random_bytes(AES.block_size)
                print("AES Key:")
                for b in aeskey:
                    print("{0:02x}".format(b),end="")
                print("\n")
                return aeskey
            else:
                print('Not supported')
        else:
            print("not supported")
        #return result
        #return public, private, session
    def verify():
        print("placeholder for verification")
        


secure = secure()
public, private =secure.generating("RSA","client")
print(public)
print(private)
#aeskey = secure.generating('AES','client')
#encrypted = secure.encrypting("RSA",public,"server")
#decrypt = secure.decrypting("RSA",private,encrypted)
#print(f'rsa decrypt{decrypt}')
#print('----------------------------------------------------------------')
#aes = secure.encrypting("AES",aeskey,"client")
#print(secure.decrypting("AES",aeskey,aes))
